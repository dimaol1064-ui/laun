package com.example.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 24)
    private val panel = Color.rgb(29, 29, 42)
    private val accent = Color.rgb(139, 92, 246)
    private val muted = Color.rgb(170, 170, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "Лаунчер"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "Minecraft Bedrock • Android"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(22))
        }
        content.addView(subtitle)

        val status = TextView(this).apply {
            text = "ГОТОВ К ЗАПУСКУ"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(190, 160, 255))
            background = rounded(panel, 14)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        content.addView(status, LinearLayout.LayoutParams(-2, -2).apply {
            bottomMargin = dp(18)
        })

        val launch = makeButton("ОТКРЫТЬ MINECRAFT")
        launch.setOnClickListener { launchMinecraft() }
        content.addView(launch, matchWrap().apply { bottomMargin = dp(20) })

        section(content, "МЕНЮ")
        infoCard(content,
            "Настройки лаунчера",
            "Здесь будут находиться параметры интерфейса и запуска."
        )
        infoCard(content,
            "Чит-функции",
            "Переключатели Fly, X-Ray и других функций пока не подключены к игре. Этот проект не изменяет Minecraft и не выдаёт фиктивные читы за работающие."
        )
        infoCard(content,
            "Совместимость",
            "Целевая игра: Minecraft Bedrock 26.52. Запуск зависит от того, установлена ли игра на устройстве."
        )

        val about = TextView(this).apply {
            text = "Версия лаунчера 1.0"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(about)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            AlertDialog.Builder(this)
                .setTitle("Minecraft не найден")
                .setMessage("Установи Minecraft Bedrock, затем попробуй снова.")
                .setPositiveButton("Понятно", null)
                .show()
        }
    }

    private fun section(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 12f
            letterSpacing = 0.1f
            setTextColor(muted)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(2, dp(4), 0, dp(10))
        }
        parent.addView(label)
    }

    private fun infoCard(parent: LinearLayout, heading: String, body: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 18)
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }
        val h = TextView(this).apply {
            text = heading
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val b = TextView(this).apply {
            text = body
            textSize = 13f
            setTextColor(muted)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(7), 0, 0)
        }
        card.addView(h)
        card.addView(b)
        parent.addView(card, matchWrap().apply { bottomMargin = dp(12) })
    }

    private fun makeButton(text: String): Button = Button(this).apply {
        this.text = text
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(accent, 16)
        minHeight = dp(56)
        stateListAnimator = null
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
