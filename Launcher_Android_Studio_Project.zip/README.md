# Лаунчер

Android Studio project for a simple Minecraft Bedrock launcher interface.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK requested by the project (compile SDK 35).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The APK will be in `app/build/outputs/apk/debug/`.

## What works
- Dark launcher UI named **Лаунчер**.
- Checks whether the Minecraft Bedrock package `com.mojang.minecraftpe` is installed.
- Opens Minecraft when the launch button is tapped.

## Important limitation
This is a launcher shell, not a game modification or cheat client. The menu does not inject code into Minecraft or enable Fly, X-Ray, Speed, KillAura, or other gameplay cheats. Those features are not implemented.
